var details1 = [
  (amphotericin = {
    usage: "fungal infections",
    define:
      "Amphotericin B is an antifungal medication that fights infections caused by fungus. Amphotericin B is used to treat serious, life-threatening fungal infections. It is not for use in treating a minor fungal infection such as a yeast infection of the mouth, esophagus, or vagina.",
    important:
      "amphotericin B is for serious, life-threatening fungal infections. It is not for use in treating a minor fungal infection (yeast infection) of the mouth, esophagus, or vagina. Do not use amphotericin B in larger amounts than recommended. An overdose can cause death.",
    "side effects":
      "Get emergency medical help if you have signs of an allergic reaction: hives; wheezing, difficult breathing; swelling of your face, lips, tongue, or throat.</br>Call your doctor at once if you have:" +
      "pale skin, easy bruising; blood in your stools; a light-headed feeling, like you might pass out; seizure (convulsions);jaundice (yellowing of the skin or eyes);build-up of fluid in your lungs--anxiety, sweating, gasping for breath, cough with foamy mucus, chest pain, fast or uneven heart rate;signs of a kidney problem--little or no urination; painful or difficult urination; swelling in your feet or ankles; feeling tired or short of breath;low potassium--confusion, uneven heart rate, extreme thirst, increased urination, leg discomfort, muscle weakness or limp feeling; or signs of new infection--fever, chills, flu symptoms, mouth and throat ulcers, rapid and shallow breathing."
  })
];

function details1() {
  var b = document.getElementById("v").value;
  console.log("Valeeeeeeeeeeeeeee" + b);

  document.getElementById("use").innerHTML = details1[0]["usage"];
  document.getElementById("define").innerHTML = "What is amphotericin ?";
  document.getElementById("answer").innerHTML = details1[0]["define"];
  document.getElementById("answer1").innerHTML = details1[0]["important"];
  document.getElementById("answer2").innerHTML = details1[0]["side effects"];
  document.getElementById("").innerHTML = b;
}
